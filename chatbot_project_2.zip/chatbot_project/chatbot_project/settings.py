SECRET_KEY='dummy'
DEBUG=True
INSTALLED_APPS=['terminal_chat']
ROOT_URLCONF='chatbot_project.urls'
ALLOWED_HOSTS=[]
DATABASES={'default':{'ENGINE':'django.db.backends.sqlite3','NAME':'db.sqlite3'}}
